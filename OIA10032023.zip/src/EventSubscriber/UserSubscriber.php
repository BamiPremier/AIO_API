<?php

namespace App\EventSubscriber;

use ApiPlatform\Core\EventListener\EventPriorities;
use App\Entity\Compte;
use App\Entity\TypeUser;
use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Event\ViewEvent;
use Symfony\Component\HttpKernel\KernelEvents;

final class UserSubscriber extends AbstractController implements EventSubscriberInterface
{
    private $em;
    public    $doctrine;

    public function __construct(EntityManagerInterface $em)
    {
        $this->em = $em;
    }

    public static function getSubscribedEvents()
    {
        return [
            KernelEvents::VIEW => ['operationAfterCreateAMember', EventPriorities::POST_WRITE]
        ];
    }

    public function operationAfterCreateAMember(ViewEvent $event): void
    {
        $User = $event->getControllerResult();
        $method = $event->getRequest()->getMethod();
        if ($User instanceof User && Request::METHOD_POST === $method) {
            $otherNumber = [];

            for ($i = 0; $i < 4; $i++) {
                try {
                    $otherNumber[] = random_int(0, 9);
                } catch (\Exception $e) {
                    echo $e;
                }
            }

            $keySecret = password_hash(($User->getPhone() . '' . $User->getPassword() . '' . (new \DateTime())->format('Y-m-d H:i:s') . '' . implode("", $otherNumber)), PASSWORD_DEFAULT);

            if (strlen($keySecret) > 100) {
                $keySecret = substr($keySecret, 0, 99);
            }
            $typeUser = $this->em->getRepository(TypeUser::class)->findOneBy(['id' => 2]);

            $User->setKeySecret($keySecret);
            $User->setTypeUser($typeUser);
            $this->em->persist($User);

            $this->createCompte($User);
        }


        // if ($User instanceof User && Request::METHOD_POST === $method) {
        //     // $roleUser = $this->em->getRepository(Roles::class)->findOneBy(['id' => 5]);


        //     if ($User->getCodeParrain() == null) {
        //         $su = $this->em->getRepository(User::class)->findBy(['status' => true]);

        //         foreach ($su as $u) {
        //             if ($u->getRole()->getId() == 1) {


        //                 $codeParrain = $u->getId() . '@' . $User->getId();
        //                 $User->setCodeParrain($codeParrain);
        //                 $this->em->persist($User);
        //                 $this->em->flush();
        //                 break;
        //             }
        //         }
        //     } else {
        //         $user =
        //             $this->em->getRepository(User::class)->findBy(['nom' => $User->getCodeParrain()]);
        //         if ($user) {
        //             $codeParrain =
        //                 $user->getCodeParrain() . '@' . $User->getId();
        //         } else {
        //             $codeParrain = $User->getCodeParrain() . '@' . $User->getId();
        //         }

        //         $newCompte = new Compte();

        //         $newCompte->setUser($user);


        //         $User->setCodeParrain($codeParrain);
        //         $this->em->persist($User);
        //         $this->em->persist($newCompte);
        //         $this->em->flush();
        //     }
        // }
    }
    public function createCompte($User)

    {

        $newCompte = new Compte();

        $newCompte->setUser($User);
        $newCompte->setSolde(0);


        // $User->setCodeParrain($codeParrain);
        $this->em->persist($User);
        $this->em->persist($newCompte);
        $this->em->flush();    # code...
    }
}
