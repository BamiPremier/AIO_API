<?php

namespace App\Entity;

use App\Repository\TypeUserRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use ApiPlatform\Core\Annotation\ApiResource;
use Symfony\Component\Serializer\Annotation\Groups;
use ApiPlatform\Core\Annotation\ApiFilter;
use ApiPlatform\Core\Annotation\ApiProperty;
use ApiPlatform\Core\Bridge\Doctrine\Orm\Filter\SearchFilter;
use ApiPlatform\Core\Bridge\Doctrine\Orm\Filter\DateFilter;
use ApiPlatform\Core\Bridge\Doctrine\Orm\Filter\ExistsFilter;
use ApiPlatform\Core\Bridge\Doctrine\Orm\Filter\BooleanFilter;

/**
 * 
 * @ApiResource(itemOperations={
 *          "get"={},
 *          "delete"={},
 * "put","patch"
 *     },
 * collectionOperations = { 
 * 
 * "get" = {
 * "normalization_context"={
 *                  "groups"={
 *                      "read:typeUser"
 *                  }
 *   }
 * },
 *    "post" = {
 *          "denormalization_context"={
 *                  "groups"={
 *                      "create:typeUser"
 *                  }
 *              }
 *              }
 * }
 * )
 * 
 * @ApiFilter(
 *    SearchFilter::class, 
 *    properties={ 
 *     
 * }
 *)       
 * @ORM\Entity(repositoryClass=TypeUserRepository::class)
 */
class TypeUser
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     * @Groups({ "read:typeUser"})
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups({"create:typeUser","read:typeUser"})
     */
    private $libelle;

    /**
     * @ORM\Column(type="boolean")
     * @Groups({"create:typeUser","read:typeUser"})
     */
    private $status;

    /**
     * @Groups({"read:typeUser"})
     * @ORM\OneToMany(targetEntity=User::class, mappedBy="typeUser")
     * 
     */
    private $users;

    public function __construct()
    {
        $this->users = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }

    public function isStatus(): ?bool
    {
        return $this->status;
    }

    public function setStatus(bool $status): self
    {
        $this->status = $status;

        return $this;
    }

    /**
     * @return Collection<int, User>
     */
    public function getUsers(): Collection
    {
        return $this->users;
    }

    public function addUser(User $user): self
    {
        if (!$this->users->contains($user)) {
            $this->users[] = $user;
            $user->setTypeUser($this);
        }

        return $this;
    }

    public function removeUser(User $user): self
    {
        if ($this->users->removeElement($user)) {
            // set the owning side to null (unless already changed)
            if ($user->getTypeUser() === $this) {
                $user->setTypeUser(null);
            }
        }

        return $this;
    }
}
